d=dir('.\*.jpg');  
d=d(~ismember({d.name},{'.','..'}));  %%% find and display jpg name
k=0;
sheet_name_used=[];
for i = 1:2:length(d)  %% deal with A, B simultaneously 
    [image_name,species_name,color_feature_1]=color_feature(['.\',d(i).name]);
    ii=i+1;
    [image_name_2,species_name_2,color_feature_2]=color_feature(['.\',d(ii).name]);
    %data={image_name;color_feature_1;color_feature_2};
    
    excel_sheet = species_name;
    expression = '[A-Za-z]+';
    sheet_name = regexpi(excel_sheet,expression,'match');
    sheet_name2 = [sheet_name{1},' ',sheet_name{2}];
    
    compare_sheet = strcmp(sheet_name_used,sheet_name2);
    if ~compare_sheet
        k=0;
    end
    
    
    
    data=[color_feature_1;color_feature_2];
    k=k+1;
    rowN = 7*(k-1)+1;
    xlsRange=['A',num2str(rowN)];
    % write into excel file
    xlswrite('all_color_features.xlsx', {image_name}, sheet_name2, xlsRange);

    xlsRange2=['A',num2str(rowN+1)];
    %write into excel file
    xlswrite('all_color_features.xlsx', data, sheet_name2, xlsRange2);
    sheet_name_used = sheet_name2;
end

% for i= 1:length(d)
%    [BW,maskedImage] = segmentImage_second(['.\',d(i).name]);
% end
