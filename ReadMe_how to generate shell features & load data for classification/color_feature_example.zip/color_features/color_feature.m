function [image_name,species_name,color_feature] = color_feature(img)
% this funcion is used to extract color histogram from orignial image

image=imread(img);

image=imread(img);
img_path=pwd;
path_name=length(img_path);
path_name=path_name+2;


% read img info
K = imfinfo(img);
k_name=K.Filename;
image_name=k_name(path_name:end-4);
species_name=k_name(path_name:end);

RGB=image;
% Convert RGB image into L*a*b* color space.
X = rgb2lab(RGB);

% Create empty mask.
BW = false(size(X,1),size(X,2));

% Flood fill
row = 5;
column = 5;
tolerance = 2.000000e-02;
normX = sum((X - X(row,column,:)).^2,3);
normX = mat2gray(normX);
addedRegion = grayconnected(normX, row, column, tolerance);
BW = BW | addedRegion;

% Invert mask
BW = imcomplement(BW);

% find black background pixel numbers 
count_zero = length(find(BW==0));

% label different parts of image
labeledImage = bwlabel(BW);
shell_stats = regionprops(labeledImage,'BoundingBox');

% display RGB segmented images respectively
%%for i = 1:numel(shell_stats)
% for i = 1:1
%     shell_single = ismember(labeledImage, i) > 0;
%     %figure, imshow(shell_single);
%     maskedRgbImage = bsxfun(@times, RGB, cast(shell_single, 'like', RGB));
%     figure, imshow(maskedRgbImage);
% end


% display RGB segmented images respectively
for i = 1:numel(shell_stats)
%for i = 1:1
    shell_single = ismember(labeledImage, i) > 0;
    %figure, imshow(shell_single);
    sub_size=find(shell_single ==1);
    [sub_size_x, sub_size_y]=size(sub_size);
    if sub_size_x > 200
        maskedRgbImage = bsxfun(@times, RGB, cast(shell_single, 'like', RGB));
        %figure, imshow(maskedRgbImage);
        %shell_single_used=shell_single;
    end
%     maskedRgbImage = bsxfun(@times, RGB, cast(shell_single, 'like', RGB));
%     figure, imshow(maskedRgbImage);
%     axis on
%     xlabel x
%     ylabel y
end




%Split into RGB Channels
Red = maskedRgbImage(:,:,1);
Green = maskedRgbImage(:,:,2);
Blue = maskedRgbImage(:,:,3);

%Get histValues for each channel
[yRed, x] = imhist(Red);
[yGreen, x] = imhist(Green);
[yBlue, x] = imhist(Blue);

% substract the background numbers
back_ground=zeros(256,1);
back_ground(1,1)=count_zero;
yRed=yRed-back_ground;
yGreen=yGreen-back_ground;
yBlue=yBlue-back_ground;

% combine three R,G,B to one matrix
color_feature= [yRed';yGreen';yBlue'];

% write into excel file
%%%xlswrite('color_features.xlsx', color_feature, 'Amoria dampieria8���ݿ�');
%%%warning('off','MATLAB:xlswrite:AddSheet'); %xlswrite displays a warning because the worksheet, xx, 
                                           %did not previously exist, but you can disable this warning.

%Plot them together in one plot
%%%plot(x, yRed, 'Red', x, yGreen, 'Green', x, yBlue, 'Blue');


