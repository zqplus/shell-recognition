d=dir('.\*.jpg');  
d=d(~ismember({d.name},{'.','..'}));  %%% find and display jpg name
k=0;
% for i= 1:length(d)
%    [obtain] = shape_extract(['.\',d(i).name]);
% end

sheet_name_used=[];
for i = 1:2:length(d)  %% deal with A, B simultaneously 
    [image_name,species_name,obtain_1]=shape_extract(['.\',d(i).name]);
    ii=i+1;
    [image_name_2,species_name_2,obtain_2]=shape_extract(['.\',d(ii).name]);
    %data={image_name;color_feature_1;color_feature_2};
    
    excel_sheet = species_name;
    expression = '[A-Za-z]+';
    sheet_name = regexpi(excel_sheet,expression,'match');
    sheet_name2 = [sheet_name{1},' ',sheet_name{2}];
    
    compare_sheet = strcmp(sheet_name_used,sheet_name2);
    if ~compare_sheet
        k=0;
    end
    
    
    
    %obtain_1=obtain_1(1:72);
    %obtain_2=obtain_2(1:72);
    data=[obtain_1;obtain_2];
    %data2=data(:,1:end-1);
    k=k+1;
    rowN = 4*(k-1)+1;
    xlsRange=['A',num2str(rowN)];
    % write into excel file
    xlswrite('all_shape_features.xlsx', {image_name}, sheet_name2, xlsRange);

    xlsRange2=['A',num2str(rowN+1)];
    %write into excel file
    xlswrite('all_shape_features.xlsx', data, sheet_name2, xlsRange2);    
    sheet_name_used = sheet_name2;
end
